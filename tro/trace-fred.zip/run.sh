#!/bin/bash

python scripts/fred.py